package de.thbrunzendorf.monitoring;

import lombok.Data;

@Data
public class ExampleData {
    private String name;
    private long value = 0L;
}
